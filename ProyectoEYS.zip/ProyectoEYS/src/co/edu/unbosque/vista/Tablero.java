package co.edu.unbosque.vista;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.Image;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Tablero extends JPanel {
	private JPanel[][] paneles;
	private JPanel tableropanel;
	private JButton[] tablerobotonoes = new JButton[9];
	private JLabel ficha_r;

	public Tablero() {

		ficha_r = new JLabel();
		ficha_r.setBounds(0, 0, 10, 10);
		ImageIcon ficha_r1 = new ImageIcon("media/ficharoja.png");
		Icon icono = new ImageIcon(
				ficha_r1.getImage().getScaledInstance(ficha_r.getWidth(), ficha_r.getHeight(), Image.SCALE_DEFAULT));
		ficha_r.setIcon(icono);

		tableropanel = new JPanel();
		tableropanel.setBounds(0, 0, 800, 800);
		tableropanel.setVisible(true);

		iniciartablero();

//		
//		paneles = new JPanel[2][2];
//		for (int i = 0; i < paneles.length; i++) {
//			for (int j = 0; j < paneles.length; j++) {
//				paneles[i][j] = new JPanel();
//
//			}
//		}
//		this.armado();
//		this.atributos();
//		this.lanzar_tablero();
//		
	}
//	public void atributos() {
//		setLayout(new GridLayout(2,2));
//		setBounds(540, 29, 650, 610);
//		
//	}
//public void armado () {
//	for (int i = 0; i < paneles.length; i++) {
//		for (int j = 0; j < paneles.length; j++) {
//			add(paneles[i][j]);
//			if((i+j+1)%2==0) {
//				paneles[i][j].setBackground(Color.BLACK);
//			}
//			else {
//				paneles[i][j].setBackground(Color.WHITE);
//			}
//			
//		}
//	}
//}
//public void lanzar_tablero() {
//	setVisible(true);
//}

	public void iniciartablero() {
		setLayout(new GridLayout(3, 3));
		for (int i = 0; i < tablerobotonoes.length; i++) {
			tablerobotonoes[i] = new JButton();
			add(tablerobotonoes[i]);

		}

	}

}
