package co.edu.unbosque.controlador;

import co.edu.unbosque.*;

public class Main {
	public static void main(String[] args) {
		Controlador controlador = new Controlador();
		controlador.ejecutar();
	}
}
